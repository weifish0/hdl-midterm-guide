// <Student_ID> <Name>

// e.g. 110123456 王大明
// Add your ID and name to FIRST line of file, or you will get 5 points penalty

`define WIDTH 8

module exam1_A(
    input wire clk,
    input wire rst,
    input wire [`WIDTH-1:0] A,
    input wire [`WIDTH-1:0] B,
    input wire [1:0] ctrl,
    output reg [`WIDTH*2-1:0] out // You can modify "reg" to "wire" if needed
);

    
endmodule